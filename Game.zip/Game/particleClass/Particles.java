package particleClass;

import pointClass.Point;

import java.util.ArrayList;
import java.awt.Graphics;

public class Particles {
    private ArrayList<Particle> particles;


    public Particles() {
        this.particles = new ArrayList<>();
    }

    public void addParticles(Point position, Point velocity, int amount) {
        for (int i = 0; i < amount; i++) {
            Point newVelocity = new Point(velocity.x, velocity.y);
            newVelocity.add(new Point(Math.random()*6-3, Math.random()*6-3));
            Particle par = new Particle(new Point(position.x, position.y), newVelocity, true);
            this.particles.add(par);
        }
    }

    public void update() {
        ArrayList<Particle> toRemove = new ArrayList<>();
        ArrayList<Particle> boomAt = new ArrayList<>();
        for (Particle par : this.particles) {
            if (par.update()) {
                toRemove.add(par);
            }
            if (par.timeAlive > 100 && par.canExplode) {
                boomAt.add(par);
            }
        }

        for (Particle par : boomAt) {
            this.boom(par, 10);
            this.particles.remove(par);
        }

        for (Particle par : toRemove) {
            this.particles.remove(par);
        }
    }

    public void boom(Particle par, int amount) {
        for (int i = 0; i < amount; i++) {
            double strength = Math.random()*5+5;
            double angle = Math.random()*360;
            double dx = Math.cos(angle)*strength;
            double dy = Math.sin(angle)*strength;
            this.particles.add(new Particle(new Point(par.position.x, par.position.y), new Point(dx, dy), false));
        }
    }

    public void draw(Graphics g) {
        for (Particle par : this.particles) {
            par.draw(g);
        }
    }
}
