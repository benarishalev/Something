package particleClass;

import java.awt.Color;
import java.awt.Graphics;

import pointClass.Point;

public class Particle {
    public Point position;
    private Point velocity;
    private Color color;
    public int timeAlive;
    public boolean canExplode;

    public Particle(Point position, Point velocity, boolean canExplode) {
        this.position = position;
        this.velocity = velocity;
        this.timeAlive = 0;
        this.canExplode = canExplode;

        if (this.canExplode) {
            this.color = new Color((int)(Math.random()*100+150), (int)(Math.random()*128), 0);
        } else {
            this.color = new Color(10, 10, 10);
        }
    }

    public boolean update() {
        this.position.add(this.velocity);
        this.timeAlive++;
        return (this.position.x > 1200 || this.position.x < 0 || this.position.y > 800 || this.position.y < 0);
    }

    public void draw(Graphics g) {
        g.setColor(this.color);
        g.fillOval((int)this.position.x, (int)this.position.y, 20, 20);
    }
}
