import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import playerClass.Player;
import pointClass.Point;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Game");

        JPanel panel = new JPanel();

        frame.add(panel);


        Player player = new Player(new Point(200, 200));

        frame.add(player);
        frame.setResizable(false);
        frame.setSize(1200, 800);
        frame.setVisible(true);

        Timer drawTimer = new Timer(8, e-> {
            player.update();
            frame.repaint();
        });
        drawTimer.start();
    }
}