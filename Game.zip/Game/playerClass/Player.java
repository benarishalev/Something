package playerClass;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import pointClass.Point;
import particleClass.Particles;

public class Player extends JPanel implements MouseMotionListener {
    private Point position;
    private Point velocity;
    private Point mousePosition;
    private double speed;
    private Color color;
    private int strength;
    private int particlesAmount;

    private int timer;

    private Particles particles;

    public Player(Point start) {
        super();

        this.speed = 7;
        this.strength = 200;
        this.color = new Color(0, 0, 0);
        this.particlesAmount = 3;

        this.position = start;
        this.velocity = new Point(0, 0);
        this.mousePosition = new Point(this.position.x, this.position.y);

        this.particles = new Particles();

        addMouseMotionListener(this);
    }

    public void update() {
        double dx = (this.position.x - this.mousePosition.x);
        double dy = (this.position.y - this.mousePosition.y);
        double distance = Math.sqrt(dx*dx + dy*dy);
        double angle = Math.atan2(dy, dx);
        this.velocity.x = Math.cos(angle) * this.speed * (this.strength-distance)/this.strength;
        this.velocity.y = Math.sin(angle) * this.speed * (this.strength-distance)/this.strength;
        this.position.add(this.velocity);

        this.timer++;
        if (Math.abs(this.velocity.x + this.velocity.y) > 2 && this.timer >= 2) {
            this.timer = 0;
            particles.addParticles(new Point(position.x+25, position.y+25), new Point(-this.velocity.x, -this.velocity.y), this.particlesAmount);
        }

        particles.update();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        mousePosition.x = e.getX();
        mousePosition.y = e.getY();
    }

    @Override
    public void mouseDragged(MouseEvent e) {}

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        particles.draw(g);

        g.setColor(this.color);
        g.fillOval((int)this.position.x, (int)this.position.y, 50, 50);
    }
}
